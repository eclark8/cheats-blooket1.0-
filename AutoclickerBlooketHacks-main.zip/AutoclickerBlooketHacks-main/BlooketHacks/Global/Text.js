print("e")
